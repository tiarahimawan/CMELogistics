import { DynamoDB } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, GetCommand } from "@aws-sdk/lib-dynamodb";
import jwt from 'jsonwebtoken';

const client = new DynamoDB({ region: "ap-southeast-1" });
const dynamodb = DynamoDBDocumentClient.from(client);

const tableName = process.env.USERS_TABLE_NAME;
const jwtSecret = process.env.JWT_SECRET_KEY; // Ensure this is set in your Lambda environment variables

export const handler = async (event) => {
    // Early return for an OPTIONS request (CORS preflight)
    if (event.httpMethod === 'OPTIONS') {
        return {
            statusCode: 200,
            headers: {
                "Access-Control-Allow-Origin": "*", // Adjust the allowed origin to match your front-end domain
                "Access-Control-Allow-Headers": "Content-Type",
                "Access-Control-Allow-Methods": "OPTIONS, POST",
            },
            body: JSON.stringify({ message: "CORS preflight" }),
        };
    }

    if (!event.body) {
        return {
            statusCode: 400,
            headers: {
                "Access-Control-Allow-Origin": "*",
            },
            body: JSON.stringify({ error: 'Invalid request body' }),
        };
    }

    let body;
    try {
        body = JSON.parse(event.body);
    } catch (error) {
        return {
            statusCode: 400,
            headers: {
                "Access-Control-Allow-Origin": "*",
            },
            body: JSON.stringify({ error: 'Could not parse request body' }),
        };
    }

    const { username, password } = body;

    if (!username || !password) {
        return {
            statusCode: 400,
            headers: {
                "Access-Control-Allow-Origin": "*",
            },
            body: JSON.stringify({ error: 'Username and password are required' }),
        };
    }

    const params = {
        TableName: tableName,
        Key: {
            'username': username
        }
    };

    try {
        const { Item } = await dynamodb.send(new GetCommand(params));

        if (Item && Item.password === password) {
            const token = jwt.sign({ username: username }, jwtSecret, { expiresIn: '1h', algorithm: 'HS256' });
            return {
                statusCode: 200,
                headers: {
                    "Access-Control-Allow-Origin": "*", // Adjust the allowed origin to match your front-end domain
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({ token: token }),
            };
        } else {
            return {
                statusCode: 401,
                headers: {
                    "Access-Control-Allow-Origin": "*",
                },
                body: JSON.stringify({ error: 'Invalid credentials' }),
            };
        }
    } catch (error) {
        console.error("Error fetching item from DynamoDB", error);
        return {
            statusCode: 500,
            headers: {
                "Access-Control-Allow-Origin": "*",
            },
            body: JSON.stringify({ error: 'Internal server error' }),
        };
    }
};
